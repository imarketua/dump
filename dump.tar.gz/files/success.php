<?
$view = View::main();
$view->set('text',$text);
$view->render('success');
?>
